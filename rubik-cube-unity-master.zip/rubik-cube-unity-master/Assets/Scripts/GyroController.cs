﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GyroController : MonoBehaviour
{
    public float rotationSpeed = 100f;
    public float orbitDampening = 10f;
    private Transform cameraPivot;
    private Vector3 localRotation;

    private BigCube bigCube;
    private float rotationAngle = 90f;

    void Start()
    {
        cameraPivot = transform.parent;
        bigCube = FindObjectOfType<BigCube>();
    }

    void Update()
    {
        HandleKeyboardInput();
    }

    void HandleKeyboardInput()
    {
        // Rotate the cube using arrow keys with smooth animation
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            StartCoroutine(SmoothRotate(Vector3.right * rotationAngle));
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            StartCoroutine(SmoothRotate(Vector3.left * rotationAngle));
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            StartCoroutine(SmoothRotate(Vector3.up * rotationAngle));
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            StartCoroutine(SmoothRotate(Vector3.down * rotationAngle));
        }

        // Camera rotation
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        localRotation.x += horizontal * rotationSpeed * Time.deltaTime;
        localRotation.y -= vertical * rotationSpeed * Time.deltaTime;

        Quaternion targetRotation = Quaternion.Euler(localRotation.y, localRotation.x, 0f);
        cameraPivot.rotation = Quaternion.Slerp(cameraPivot.rotation, targetRotation, Time.deltaTime * orbitDampening);
    }

    IEnumerator SmoothRotate(Vector3 rotation)
    {
        Quaternion startRotation = bigCube.transform.rotation;
        Quaternion endRotation = startRotation * Quaternion.Euler(rotation);
        float time = 0;

        while (time < 1)
        {
            bigCube.transform.rotation = Quaternion.Lerp(startRotation, endRotation, time);
            time += Time.deltaTime * 2; // Adjust speed
            yield return null;
        }

        bigCube.transform.rotation = endRotation;
    }
}
