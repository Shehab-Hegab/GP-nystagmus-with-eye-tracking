﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyboardInputController : MonoBehaviour
{
    public float rotationSpeed = 100f;
    public float orbitDampening = 10f;
    private Transform cameraPivot;
    private Vector3 localRotation;

    private BigCube bigCube;
    private float rotationAngle = 90f;

    void Start()
    {
        cameraPivot = transform.parent;
        bigCube = FindObjectOfType<BigCube>();
    }

    void Update()
    {
        HandleKeyboardInput();
    }

    void HandleKeyboardInput()
    {
        // Rotate the cube using arrow keys
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            StartCoroutine(bigCube.RotateAlongX(rotationAngle, 0));
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            StartCoroutine(bigCube.RotateAlongX(-rotationAngle, 0));
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            StartCoroutine(bigCube.RotateAlongY(-rotationAngle, 0));
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            StartCoroutine(bigCube.RotateAlongY(rotationAngle, 0));
        }

        // Camera rotation
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        localRotation.x += horizontal * rotationSpeed * Time.deltaTime;
        localRotation.y -= vertical * rotationSpeed * Time.deltaTime;

        Quaternion targetRotation = Quaternion.Euler(localRotation.y, localRotation.x, 0f);
        cameraPivot.rotation = Quaternion.Slerp(cameraPivot.rotation, targetRotation, Time.deltaTime * orbitDampening);
    }
}
